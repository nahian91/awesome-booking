=== Awesome Booking ===
Contributors: awesomeplugins91
Tags: booking, hotel, hotels, hotel booking, rooms
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A lightweight hotel booking plugin for WordPress. Add and manage hotels and room details easily.

== Description ==
Awesome Booking is a minimal hotel booking plugin for WordPress. You can add hotels, set room availability, price per night, and display them on the front-end using the [abeg_hotels] shortcode. Perfect for lightweight and simple hotel booking functionality.

== Installation ==
1. Upload the `awesome-booking` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Add hotels via the "Hotels" menu under "Awesome Booking" in the WordPress admin.
4. Display hotels on any page or post using the shortcode: `[abeg_hotels]`.

== Frequently Asked Questions ==

= How do I display hotels on my site? =
Use the shortcode `[abeg_hotels]` on any page or post.

= Can I set different prices for rooms? =
Currently, each hotel has a single price per night. Room-specific pricing will be added in future updates.

== Screenshots ==
1. Hotel list displayed on front-end.
2. Hotel edit screen with price and availability fields.
3. Awesome Booking admin menu in WordPress dashboard.

== Changelog ==
= 1.0 =
* Initial release with hotel CPT, meta boxes, and shortcode display.

== Upgrade Notice ==
= 1.0 =
Initial release.

== Arbitrary section ==
This plugin is created by Abdullah Nahian. For support, visit https://devnahian.com
