<?php
/*
Plugin Name: Awesome Booking
Plugin URI: https://devnahian.com/awesome-booking
Description: A lightweight hotel booking plugin for WordPress. Add and manage hotels, room details, easily.
Version: 1.0
Author: Abdullah Nahian
Author URI: https://devnahian.com
License: GPL2
Text Domain: awesome-booking
Domain Path: /languages
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Prevent direct access

/**************************************************************
 * 1. Enqueue CSS
 **************************************************************/
add_action('wp_enqueue_scripts', 'abeg_enqueue_frontend_styles');
function abeg_enqueue_frontend_styles() {
    wp_enqueue_style('abeg-frontend-css', plugins_url('assets/css/frontend.css', __FILE__), [], '1.0');
}

add_action('admin_enqueue_scripts', 'abeg_enqueue_admin_styles');
function abeg_enqueue_admin_styles($hook) {
    wp_enqueue_style('abeg-admin-css', plugins_url('assets/css/admin.css', __FILE__), [], '1.0');
}

/**************************************************************
 * 2. Admin Menu
 **************************************************************/
add_action('admin_menu', 'abeg_register_main_menu');
function abeg_register_main_menu() {
    add_menu_page(
        esc_html__('Awesome Booking', 'awesome-booking'),
        esc_html__('Awesome Booking', 'awesome-booking'),
        'manage_options',
        'abeg-dashboard',
        'abeg_dashboard_page',
        'dashicons-calendar-alt',
        25
    );

    add_submenu_page('abeg-dashboard', esc_html__('Dashboard', 'awesome-booking'), esc_html__('Dashboard', 'awesome-booking'), 'manage_options', 'abeg-dashboard', 'abeg_dashboard_page');
    add_submenu_page('abeg-dashboard', esc_html__('Hotels', 'awesome-booking'), esc_html__('Hotels', 'awesome-booking'), 'manage_options', 'edit.php?post_type=abeg_hotel');
    add_submenu_page('abeg-dashboard', esc_html__('Settings', 'awesome-booking'), esc_html__('Settings', 'awesome-booking'), 'manage_options', 'abeg-settings', 'abeg_settings_page');
}

/**************************************************************
 * 3. Register CPT
 **************************************************************/
add_action('init', 'abeg_register_cpt');
function abeg_register_cpt() {
    register_post_type('abeg_hotel', [
        'labels' => [
            'name' => esc_html__('Hotels', 'awesome-booking'),
            'singular_name' => esc_html__('Hotel', 'awesome-booking'),
            'add_new' => esc_html__('Add New Hotel', 'awesome-booking'),
            'add_new_item' => esc_html__('Add New Hotel', 'awesome-booking'),
            'edit_item' => esc_html__('Edit Hotel', 'awesome-booking'),
        ],
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => false,
        'supports' => ['title', 'editor', 'thumbnail'],
    ]);
}

/**************************************************************
 * 4. Hotel Meta Box
 **************************************************************/
add_action('add_meta_boxes', 'abeg_add_hotel_metabox');
function abeg_add_hotel_metabox() {
    add_meta_box('abeg_hotel_details', esc_html__('Hotel Details', 'awesome-booking'), 'abeg_hotel_details_callback', 'abeg_hotel', 'normal', 'high');
}

function abeg_hotel_details_callback($post) {
    $price = get_post_meta($post->ID, '_abeg_price', true);
    $availability = get_post_meta($post->ID, '_abeg_availability', true);
    wp_nonce_field('abeg_save_hotel_details', 'abeg_hotel_nonce');
    ?>
    <p>
        <label for="abeg_price"><strong><?php esc_html_e('Price per night ($):', 'awesome-booking'); ?></strong></label><br>
        <input type="number" name="abeg_price" id="abeg_price" value="<?php echo esc_attr($price); ?>" style="width:100%;" min="0" step="0.01">
    </p>
    <p>
        <label for="abeg_availability"><strong><?php esc_html_e('Available Rooms:', 'awesome-booking'); ?></strong></label><br>
        <input type="number" name="abeg_availability" id="abeg_availability" value="<?php echo esc_attr($availability); ?>" style="width:100%;" min="0" step="1">
    </p>
    <?php
}

/**************************************************************
 * 5. Save Post
 **************************************************************/
add_action('save_post_abeg_hotel', 'abeg_save_hotel_details');
function abeg_save_hotel_details($post_id) {

    // Check nonce
    if ( isset( $_POST['abeg_hotel_nonce'] ) ) {
        $nonce = sanitize_text_field( wp_unslash( $_POST['abeg_hotel_nonce'] ) );
        if ( ! wp_verify_nonce( $nonce, 'abeg_save_hotel_details' ) ) {
            return;
        }
    } else {
        return;
    }

    // Bail out if autosave
    if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return;

    // Check user permissions
    if ( ! current_user_can('edit_post', $post_id) ) return;

    // Save price
    if ( isset( $_POST['abeg_price'] ) ) {
        $price = floatval( $_POST['abeg_price'] );
        update_post_meta( $post_id, '_abeg_price', $price );
    }

    // Save availability
    if ( isset( $_POST['abeg_availability'] ) ) {
        $availability = intval( $_POST['abeg_availability'] );
        update_post_meta( $post_id, '_abeg_availability', $availability );
    }
}

/**************************************************************
 * 6. Shortcode [abeg_hotels]
 **************************************************************/
add_shortcode('abeg_hotels', 'abeg_display_hotels');
function abeg_display_hotels() {
    $query = new WP_Query([
        'post_type' => 'abeg_hotel',
        'posts_per_page' => -1,
    ]);

    ob_start();

    if ( $query->have_posts() ) :
        echo '<div class="abeg-hotel-list">';
        while ( $query->have_posts() ) : $query->the_post();
            $price = get_post_meta(get_the_ID(), '_abeg_price', true);
            $availability = get_post_meta(get_the_ID(), '_abeg_availability', true);
            ?>
            <div class="abeg-hotel-item">
                <h3><?php echo esc_html( get_the_title() ); ?></h3>
                <div class="abeg-thumbnail"><?php the_post_thumbnail('medium'); ?></div>
                <div class="abeg-content"><?php echo wp_kses_post( get_the_content() ); ?></div>
                <p><strong><?php esc_html_e('Price:', 'awesome-booking'); ?></strong> <?php echo esc_html($price); ?> USD/night</p>
                <p><strong><?php esc_html_e('Available Rooms:', 'awesome-booking'); ?></strong> <?php echo esc_html($availability); ?></p>
                <button class="abeg-book-button"><?php esc_html_e('Book Now', 'awesome-booking'); ?></button>
            </div>
            <?php
        endwhile;
        echo '</div>';
        wp_reset_postdata();
    else:
        echo '<p>' . esc_html__('No hotels found.', 'awesome-booking') . '</p>';
    endif;

    return ob_get_clean();
}

/**************************************************************
 * 7. Dashboard & Settings Pages
 **************************************************************/
function abeg_dashboard_page() {
    if ( ! current_user_can('manage_options') ) return;
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Awesome Booking Dashboard', 'awesome-booking'); ?></h1>
        <p><?php esc_html_e('Welcome to Awesome Booking! Use the menu to manage hotels.', 'awesome-booking'); ?></p>
    </div>
    <?php
}

function abeg_settings_page() {
    if ( ! current_user_can('manage_options') ) return;
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Awesome Booking Settings', 'awesome-booking'); ?></h1>
        <p><?php esc_html_e('Configure your booking settings here.', 'awesome-booking'); ?></p>
    </div>
    <?php
}
